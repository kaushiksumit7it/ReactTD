export const userData = [
  {
    id: 1,
    name: "Akpareva don",
  },
  {
    id: 2,
    name: "John Doe",
  },
  {
    id: 3,
    name: "Sarah Conor",
  },
  {
    id: 4,
    name: "Blessing Foo",
  },
  {
    id: 5,
    name: "Grace Eze",
  },
];
