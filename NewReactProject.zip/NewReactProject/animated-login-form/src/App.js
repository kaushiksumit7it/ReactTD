import "./App.scss";
import AuthContainer from "./components/auth/AuthContainer";

function App() {
  return (
    <div>
      <AuthContainer />
    </div>
  );
}

export default App;
