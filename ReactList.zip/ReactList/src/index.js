import React from 'react';  
import ReactDOM from 'react-dom';  
import Garage from './Garage.js';  
  
  
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Garage/>);