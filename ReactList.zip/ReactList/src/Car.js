function Car(props) {
  return <li>I am a { props.brand }</li>;
}

export default Car;
