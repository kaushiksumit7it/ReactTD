import React from 'react';   
import ReactDOM from 'react-dom';   
function Show(props)   
{   
    if(!props.displayMessage)   
        return null;   
    else  
        return <h3>Component is rendered</h3>;   
} 

export default Show;
