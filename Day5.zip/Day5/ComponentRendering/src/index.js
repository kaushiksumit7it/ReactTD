import React from 'react';  
import ReactDOM from 'react-dom';  
import Show from './Show.js';  
  
  
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Show displayMessage = {true}  />);