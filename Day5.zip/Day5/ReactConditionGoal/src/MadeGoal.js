function MadeGoal() {
  return <h1>Goal!</h1>;
}

export default MadeGoal;
