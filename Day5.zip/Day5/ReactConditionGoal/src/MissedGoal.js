function MissedGoal() {
  return <h1>MISSED!</h1>;
}

export default MissedGoal;
