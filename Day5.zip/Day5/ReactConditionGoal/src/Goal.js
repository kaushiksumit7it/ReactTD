import MadeGoal from './MadeGoal.js'; 
import MissedGoal from './MissedGoal.js'; 
function Goal(props) {
  const isGoal = props.isGoal;
  if (isGoal) {
    return <MadeGoal/>;
  }
  return <MissedGoal/>;
}

export default Goal;
