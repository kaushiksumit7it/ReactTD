import React from 'react';  
import ReactDOM from 'react-dom';  
import Goal from './Goal.js';  
  
  
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Goal isGoal={false} />);